import { Component, OnInit } from '@angular/core';
import {MessageService} from 'primeng/api';

import { Product } from '../common/product';
import { ProductsService } from '../common/products.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss'],
  providers: [MessageService]
})
export class ProductListComponent implements OnInit {

  constructor(private messageService: MessageService,private productsService:ProductsService) { 

  }

  showAddProductDialog = false;
  selectedProduct:Product = {};
  // need to replace this mock data with API data
  products:Product[] = [
    {
      "quantity": 1,
      "id": "4dbbe4e7-9716-4843-8e4c-d93f1b92cea5",
      "price": 100,
      "name": "mqmSrgBKbv00002"
    },
    {
      "quantity": 11,
      "id": "121226",
      "price": 10.9,
      "name": "name3name"
    },
    {
      "quantity": 11,
      "id": "12122",
      "price": 10.9,
      "name": "name27name"
    },
    {
      "quantity": 23,
      "id": "product23",
      "price": 10.4,
      "name": "name23"
    },
    {
      "quantity": 1,
      "id": "48dbdfb4-a6c3-4c08-aedc-036707021ef4",
      "price": 2211,
      "name": "mqmSrgBKbv00002"
    },
    {
      "quantity": 1,
      "id": "6fa7ba32-831a-49e0-83ff-07f3f7a19669",
      "price": 100,
      "name": "mqmSrgBKbv00002"
    },
    {
      "quantity": 10,
      "id": "product19",
      "price": 10.9,
      "name": "name1"
    },
    {
      "quantity": 1,
      "id": "422182cb-3db5-444b-b944-8356f0eba8bc",
      "price": 100,
      "name": "mqmSrgBKbv00002"
    },
    {
      "quantity": 10,
      "id": "product26",
      "price": 10.9,
      "name": "name26"
    },
    {
      "quantity": 1,
      "id": "3900da61-8dcb-4222-b4cf-0a1f49765f05",
      "price": 100,
      "name": "mqmSrgBKbv00002"
    }
  ];

  ngOnInit(): void {
    this.getAllProducts();
  }

  handleDialogClose(requiredReload:boolean){
    if(requiredReload){
      this.getAllProducts();
    }
    this.showAddProductDialog = false;
  }
 
  hanldeEditProduct(product:Product){
    this.selectedProduct = product;
  }
  
  showDialog(){
    this.showAddProductDialog = true;
  }

  deleteProduct(productId:string){
    console.log(productId);
    this.productsService.deleteProduct(productId).subscribe(response => {
      console.log(response);
      this.getAllProducts();
   },(error:any) =>{
    this.messageService.add({severity:'error', summary: 'Error', detail: error.error.message});
   });
  }
 
  getAllProducts(){
    this.productsService.getAllProducts().subscribe((data: any[])=>{
      console.log(data);
      this.products = data;
    },(error:any) =>{
      this.messageService.add({severity:'error', summary: 'Error', detail: error.error.message});
     });
  }

}
