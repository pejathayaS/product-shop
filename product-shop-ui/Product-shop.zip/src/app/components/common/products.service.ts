import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  API_PATH="https://ev5uwiczj6.execute-api.eu-central-1.amazonaws.com/test/supply-chain";
  API_TIMEOUT = 10000;
  constructor(private httpClient:HttpClient) { 
  }

  getAllProducts(): Observable<Product[]> {
    return this.httpClient.get<any>(`${this.API_PATH}`);
  }

  addProduct(product:Product): Observable<any> {
    return this.httpClient.post<any>(`${this.API_PATH}/`,product);
  }
  deleteProduct(productId:string): Observable<any> {
    return this.httpClient.delete<any>(`${this.API_PATH}/${productId}`);
  }
  editProduct(product:Product): Observable<any> {
    return this.httpClient.put<any>(`${this.API_PATH}/${product.id}`, product);
  }
 
}
