import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Product } from '../common/product';
import { ProductsService } from '../common/products.service';

@Component({
  selector: 'app-product-add-edit',
  templateUrl: './product-add-edit.component.html',
  styleUrls: ['./product-add-edit.component.scss']
})
export class ProductAddEditComponent implements OnInit {
  @Input() showAddProductDialog = true;
  @Input() onSelectedProduct = true;
  
  @Output() onCloseDialog: EventEmitter<any> = new EventEmitter<any>();
  product:Product = {
   
  }
  constructor(private productsService:ProductsService) {
    console.log('tesyt');
   }
  

  ngOnInit(): void {
  }
  addProduct(){
    console.log(this.product);
    this.productsService.editProduct(this.product).subscribe(response => {
        console.log(response);
        this.onCloseDialog.emit(true);
     },(error:any) =>{
      console.log(error)
     });
    
  }
  editProduct(product:Product){
    console.log(product);
    this.productsService.editProduct(product).subscribe(response => {
      this.onCloseDialog.emit(true);
   },(error:any) =>{
    console.log(error)
   });
  }
  closeDialog(){
    this.onCloseDialog.emit(false);
  }
}
